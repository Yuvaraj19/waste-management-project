<!DOCTYPE HTML>

<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />
	

	<link href='https://fonts.googleapis.com/css?family=Raleway:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body1>
		

	<header id="gtco-header" class="gtco-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);">
			<div class="row" style="padding: 50px 60px">
				<div class="col-md-12 col-md-offset-0 text-center">
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
								<form name="f4" method="POST" action="http://localhost/order.php" style="padding: 50px 50px;box-sizing: 50px 50px">
							    <?php
								$id=$_POST["id"];
								$qty=$_POST["qty"];
								session_start();

								$servername = "localhost";
								$username = "root";
								$password = "";
								$dbname = "reuse";

								// Create connection
								$conn = mysqli_connect($servername, $username, $password, $dbname);

								// Check connection
								if ($conn->connect_error) {
									die("Connection failed: " . $conn->connect_error);
								}

								$sql2 = "SELECT * FROM registration WHERE id='$id'";
								$result2 = mysqli_query($conn,$sql2);
								
								
								if ($result2->num_rows > 0) {
									$row2 = $result2->fetch_assoc();
									
									$v1=$row2["email"];
									
									$sql3 = "SELECT * FROM producer WHERE email='$v1'";
									$result3 = mysqli_query($conn,$sql3);
									$row3 = $result3->fetch_assoc();
									
									$cost = $row3["price"]*$qty;
									$j=0;
									if($qty < 100) {
										$tr = 5000;
									}
									if($qty >= 100) {
										$tr = 7500;
									}
									if($qty >= 200) {
										$tr = 10000;
									}
									$gst = 0.07*$cost;

									$cost1 = $gst+$cost;

									$cost2 = $cost1+$tr;

									$_SESSION['Qty']=$qty;
									$_SESSION['Type']=$row3['type'];
									$_SESSION['Pro']=$row2['email'];
									$_SESSION['Trans']=$tr;
									$_SESSION['Cost']=$cost;
									$_SESSION['Total']=$cost2;
									
									if($qty <= $row3['qty']) {
									
									echo "<font color='black' size='5px'>"."Producer : ".$row2['cname']."<br>"
									."Product : ".$row3['type']."<br>"
									."Location : ".$row2['location']."<br>"
									."Quantity mentioned : ".$qty." kg/ltr"."<br>"
									."----------------------------------------"."<br>"
									."Total cost : ". $cost . "/-"."<br>"
									."GST (7%) : " . $cost1 . "/-"."<br>"
									."Transportaion charges : ".$tr."/-"."<br>"
									."----------------------------------------"."<br>"
									."Grand Total : ".$cost2."/-"."</font>"."<br>"."<br>"
									."<button class='btn btn-primary btn-lg-1' align='center'>"."Submit"."</button>";


									}
									else {
										echo "Mentioned Quantity not available from producer"."<br>".
										"Please go back and give valid inputs."."<br>".
										"<button class='btn btn-primary btn-lg-1' align='center'>"."Back"."</button>";
									}
								}
								
								?>
								</form>

						</div>
					</div>
				</div>
			</div>

	</header>
	

	
	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body1>
</html>