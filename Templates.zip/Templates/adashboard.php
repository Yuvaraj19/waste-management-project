<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";

$conn = new mysqli($servername, $username, $password, $dbname);

$sql = "SELECT type, count(*) as number FROM producer GROUP BY type";
$result = mysqli_query($conn,$sql); 
?>
<!DOCTYPE html>
<html>

<head>

<style>
 .sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 8px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
  google.charts.load('current', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);
  function drawChart() {
    var data = google.visualization.arrayToDataTable([
      ['Type','Number'],
      <?php
      while($row = mysqli_fetch_array($result)) {
        echo "['".$row["type"]."',".$row["number"]."],";
      }
      ?>
    ]);
    var options = {
      title: 'Percentage of different types of wastes registered',
      is3D:true,
    };
    var chart = new google.visualization.PieChart(document.getElementById('piechart'));
    chart.draw(data, options);
  }
</script>

</head>


<body style="background-image: url(images/p3.jpg)">
  <font color="black">
  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
<div id="sidenav" class="sidenav">
   <a href="javascript:void(0)" class="closebtn" align="right" onclick="closeNav()">&times;</a>
    <a href="adashboard.php" class="active">Dashborad</a>
    <a href="review.php">Reviews</a>
    <a href="aorders.php">Orders</a>
    <a href="complaints.php">Complaints(<?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "reuse";
          $j=0;
          $conn = new mysqli($servername, $username, $password, $dbname);

          $sql1 = "SELECT status FROM recom";
        $result1 = mysqli_query($conn,$sql1); 
         while($row1 = $result1->fetch_assoc()) {
         if($row1['status'] == "NOT SOLVED") {
          $j++;
         }
      }
      echo $j;

        ?>)</a>


</div>


<div class="gtco-container">
  <table class="columns">
    <tr>
      <th><div id="piechart" style="width: 900px; height: 500px;padding-left: 75px"></div></th>
      <th><div style="padding-right: 100px; padding-bottom: 150px">
      <h2>Registered types of waste.</h2>
      <p>this pie chart shows the percentages of registerd types of wastes produced by the registered companies/industries.</p>
    </div></th>
  </div>
  </div>
</div>
	
	
	<script>
function openNav() {
  document.getElementById("sidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("sidenav").style.width = "0";
}
</script>
	
</font>
</body>

</html>