<?php
session_start();

$email = $_POST['email'];
$pswd= $_POST['pswd'];

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "reuse";

$conn =mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    printf("connection failed!");
}
else
{	
$query="SELECT * FROM registration WHERE email='$email' AND pswd='$pswd'";
	
	if($result=mysqli_query($conn,$query))
	{
		$count = mysqli_num_rows($result); 
		
		if($count==0)
		{
			printf("login failed, Due to authentication failure. \n ");
			
			echo 'PLEASE TRY AGAIN AS WE REDIRECT YOU TO LOGIN PAGE';
			header( "refresh:2;url=index.html" );
		}
		else{
			$row0=$result->fetch_assoc();
			
		echo 'logged in successfully, PLEASE WAIT WHILE WE REDIRECT YOU TO HOMEPAGE...  Welcome : ';
		$_SESSION['Email']=$email;
		echo "<font color='red'>".$email."</font>";
		header( "refresh:2;url=dashboard.html" );
		
	}
	}
}
?>


