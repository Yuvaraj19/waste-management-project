
<!DOCTYPE html>
<html>

<head>

  <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  .btn {
  margin-right: 4px;
  margin-bottom: 4px;
  font-family: "Raleway", Arial, sans-serif;
  font-size: 16px;
  font-weight: 400;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  -ms-border-radius: 4px;
  border-radius: 4px;
  -webkit-transition: 0.5s;
  -o-transition: 0.5s;
  transition: 0.5s;
  padding: 8px 30px;
}
.btn-primary {
  background: #F85A16;
  color: #fff;
  border: 2px solid #F85A16 !important;
}
.btn.btn-lg {
  padding: 18px 36px !important;
}
  .sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 8px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  padding-left: 200px;
}

td, th {
  border: 1px solid black;
  text-align: left;
  padding: 10px 20px;
}

tr {
  background-color: #ccc;
}
</style>

</head>


<body style="background-image: url(images/p3.jpg)">
  <font color="black">

  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
<div id="sidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" align="right" onclick="closeNav()">&times;</a>
    <a href="adashboard.php">Dashborad</a>
    <a href="review.php" class="active">Reviews</a>
    <a href="aorders.php">Orders</a>
    <a href="complaints.php">Complaints(<?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "reuse";
          $j=0;
          $conn = new mysqli($servername, $username, $password, $dbname);

          $sql1 = "SELECT status FROM recom";
        $result1 = mysqli_query($conn,$sql1); 
         while($row1 = $result1->fetch_assoc()) {
         if($row1['status'] == "NOT SOLVED") {
          $j++;
         }
      }
      echo $j;

        ?>)</a>


</div>


<h1 align="center">REVIEWS</h1>
<header id="gtco-header" class="gtco-cover" role="banner">
    

          <div class="display-t">
            <div class="display-tc animate-box" data-animate-effect="fadeIn">
              <div>
                <table style="padding: 7px; margin-left: 20px; margin-right: 20px;">
                  <tr>
                    <th style="padding: 10px 10px">S.No</th>
                    <th style="padding: 10px 20px">Company</th>
                    <th style="padding: 10px 40px">Email</th>
                    <th style="padding: 10px 20px">Mobile</th>
                    <th style="padding: 10px 50px">Date,Time</th>
                    <th style="padding: 10px 40px">Description</th>
                  </tr>
                

<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";
$destype2 = "Review";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql3 = "SELECT * FROM recom WHERE destype='$destype2'";
$result3 = mysqli_query($conn,$sql3);

if ($result3->num_rows > 0) {
    
  // output data of each row
  $i=1;
  while($row3 = $result3->fetch_assoc()) 
  {
    $v1= $row3["email"];
    $sql7 = "SELECT * FROM registration WHERE email='$v1'";
    $result7 = mysqli_query($conn,$sql7);
    $sql8 = "SELECT * FROM recom WHERE email='$v1'";
    $result8 = mysqli_query($conn,$sql8);

    if ($result7->num_rows > 0 AND $result8->num_rows > 0) {
    // output data of each row
    while($row7 = $result7->fetch_assoc() AND $row8 = $result8->fetch_assoc()) 
    {
     
      echo "<tr>"."<th style='padding: 10px 30px' >".$i."</th>"
      ."<th style='padding: 10px 40px'>". $row7['cname'] ."</th>"
      ."<th style='padding: 10px 50px'>". $row7['email'] ."</th>"
      ."<th style='padding: 10px 30px'>". $row7['mobile'] ."</th>"
      ."<th style='padding: 10px 40px'>". $row8['date'] ."</th>"
      ."<th style='padding: 10px 30px'>". $row8['des'] ."</th>"
      ."</tr>";
      
      $i++;
    }
}
else 
{
    echo "0 results";
}

    }
}
else 
{
    echo "0 results";
}


?>

          </table><br>
        </div>
        </div>
        </div>
</header>
  
  <script>
function openNav() {
  document.getElementById("sidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("sidenav").style.width = "0";
}
</script>
  
  
</font>
</body>

</html>