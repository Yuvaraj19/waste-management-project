<?php 

$orderno = $_POST['orderno'];
$status1 = $_POST['status1'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql1 = "UPDATE orders SET status1 = '$status1', deldate = CURRENT_TIMESTAMP WHERE orderno = '$orderno'";
$result1=mysqli_query($conn, $sql1);
header("refresh:2;url=aorders.php");
?>