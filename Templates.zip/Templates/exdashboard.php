
<!DOCTYPE html>
<html>

<head>
<style>
  .btn {
  margin-right: 4px;
  margin-bottom: 4px;
  font-family: "Raleway", Arial, sans-serif;
  font-size: 16px;
  font-weight: 400;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  -ms-border-radius: 4px;
  border-radius: 4px;
  -webkit-transition: 0.5s;
  -o-transition: 0.5s;
  transition: 0.5s;
  padding: 8px 30px;
}
.btn-primary {
  background: #F85A16;
  color: #fff;
  border: 2px solid #F85A16 !important;
}
.btn.btn-lg {
  padding: 18px 36px !important;
}
  .sidenav {
  height: 100%;
  width: 200;
  position: absolute;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 8px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>

</head>


<body>



  <font color="black">
<header>


<h1 align="center">ORDERS</h1>

<header id="gtco-header" class="gtco-cover" role="banner">
    
          <div class="display-t">
            <div class="display-tc animate-box" data-animate-effect="fadeIn">
              <form name="f7" method="POST" action="check3.php">
              <div>
                <table style="padding: 7px; margin-left: 20px; margin-right: 20px;">
                  <tr>
                    <th style="padding: 10px 10px">S.No</th>
                    <th style="padding: 10px 20px">Order no.</th>
                    <th style="padding: 10px 20px">Producer details</th>
                    <th style="padding: 10px 40px">Consumer details</th>
                    <th style="padding: 10px 20px">Date of order</th>
                    <th style="padding: 10px 40px">Status</th>
                  </tr>
                

<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";
$exid = $_SESSION['Exid'];
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql3 = "SELECT * FROM trans WHERE exid = '$exid'";
$result3 = mysqli_query($conn,$sql3);

if ($result3->num_rows > 0) {
    
  // output data of each row
  $i=1;
  while($row3 = $result3->fetch_assoc()) 
  {
    $ono = $row3['orderno'];
    $sql4 = "SELECT * FROM orders WHERE orderno ='$ono'";
    $result4 = mysqli_query($conn,$sql4);
    $row4 = $result4->fetch_assoc();
    $v1= $row4["promail"];
    $v2= $row4["conmail"];
    $sql7 = "SELECT * FROM registration WHERE email='$v1'";
    $result7 = mysqli_query($conn,$sql7);
    $sql8 = "SELECT * FROM registration WHERE email='$v2'";
    $result8 = mysqli_query($conn,$sql8);

    if ($result7->num_rows > 0 AND $result8->num_rows > 0) {
    // output data of each row
    while($row7 = $result7->fetch_assoc() AND $row8 = $result8->fetch_assoc()) 
    {
     
      echo "<tr>"."<th style='padding: 10px 30px' >".$i."</th>"
      ."<th style='padding: 10px 30px' >".$row3['orderno']."</th>"
      ."<th style='padding: 10px 40px'> Company name :". $row7['cname'] ."<br>Email :".$row7['email']."<br>Mobile : ".$row7['mobile']."<br>Landline :".$row7['lmobile']."<br>Location : ".$row7['location']."</th>"
      ."<th style='padding: 10px 50px'>Company name : ". $row8['cname'] ."<br>Email : ".$row8['email']."<br>Mobile : ".$row8['mobile']."<br>Landline : ".$row8['lmobile']."<br>Location : ".$row8['location']."</th>"
      ."<th style='padding: 10px 30px'>". $row4['ordate'] ."</th>"
      ."<th style='padding: 10px 30px'>". $row3['status2'] ."</th>"
      ."</tr>";
      
      $i++;
    }
}
else 
{
    echo "0 results";
}

    }
}
else 
{
    echo "0 results";
}


?>

          </table><br>
        </div>
          <div class="wm-section wm-text-white" align="center">
                  <label1 for="type" ><b>Enter order id</b></label1><br>
                <input type="text" placeholder="Enter order id" name="orderno" style = "width : 300px;border-radius : 5px; padding-left : 10px;margin-bottom : 30px" required>
                <br><br>
                 <label1 for="type" ><b>Enter Status</b></label1><br>
                <input type="text" placeholder="Enter status" name="status2" style = "width : 300px;border-radius : 5px; padding-left : 10px;margin-bottom : 30px" required><br><br>
                <button type="submit" class="btn btn-primary btn-lg-1">Submit</button>
              </div>

      </form>
        </div>
        </div>
</header>
	
	
	
	
</font>
</body>

</html>