<?php

$email = $_POST["email"];
$type = $_POST["type"];
$qty = $_POST["qty"];
$price = $_POST["price"];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";

$conn = new mysqli($servername, $username, $password, $dbname);

if($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
$sql1 = "SELECT type FROM producer WHERE email='$email'";
$result=mysqli_query($conn, $sql1);
$row = $result->fetch_assoc();

if( $type == $row['type']) {
	echo "This type of waste is already entered by you...!";
	header("refresh:2;url=producer.html");
} else {
$sql = "INSERT INTO producer (email, type, qty, price) VALUES ('$email','$type','$qty', '$price')";
echo "Submitted Successfully";
header("refresh:2;url=dashboard.html");
}

?>
