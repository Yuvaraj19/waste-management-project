<?php 

$compid = $_POST['compid'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";
$destype2 = "Complaint";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE recom SET status = 'SOLVED' WHERE compid = '$compid'";
$result=mysqli_query($conn, $sql);
echo "Action for selected complaint is 'SOLVED'.";
?>