<?php 

$orderno = $_POST['orderno'];
$status2 = $_POST['status2'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if($status2 == 'CANCELLED') {
	$sql2 = "SELECT * FROM orders WHERE orderno = '$orderno'";
	$result2 = mysqli_query($conn, $sql2);
	$row2 = $result2->fetch_assoc();

	$q1 = $row2['qty'];
	$e1 = $row2['promail'];


	$sql3 = "SELECT * FROM producer WHERE email = '$e1'";
	$result3 = mysqli_query($conn, $sql3);
	$row3 = $result3->fetch_assoc();

	$q2 = $row3['qty'];

	$qf = $q2+$q1;

	$sql4 = "UPDATE producer SET qty = '$qf' WHERE email = '$e1'";
	$result4 = mysqli_query($conn, $sql4);

}

$sql1 = "UPDATE orders SET status1 = '$status2', deldate = CURRENT_TIMESTAMP WHERE orderno = '$orderno'";
$result1=mysqli_query($conn, $sql1);
$sql1 = "UPDATE trans SET status2 = '$status2' WHERE orderno = '$orderno'";
$result1=mysqli_query($conn, $sql1);

$sql4 = "DELETE FROM `trans` WHERE `trans`.`orderno` = '$orderno'";
$result4 = mysqli_query($conn, $sql4);
header("refresh:1;url=exdashboard.php");
?>