<?php
session_start();
$exid=$_POST['exid'];
$expswd=$_POST['expswd'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";
$destype2 = "Complaint";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM trans1 WHERE exid = '$exid'";
$result = mysqli_query($conn, $sql);
$row = $result->fetch_assoc();

if($exid == $row['exid'] AND $expswd == $row['expswd']) {
$_SESSION['Exid'] = $exid;
echo "Logged in successfully....Welcome Executive...!";
header("refresh:2;url=exdashboard.php");
} else {
echo "Wrong creddentilas...!";
header("refresh:2;url=exlog.php");
}

?>
