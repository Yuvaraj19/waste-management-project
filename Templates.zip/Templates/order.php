<?php
session_start();
$qty1=$_SESSION['Qty'];
$type1=$_SESSION['Type'];
$promail=$_SESSION['Pro'];
$conmail=$_SESSION['Email'];
$trans=$_SESSION['Trans'];
$cost=$_SESSION['Cost'];
$tot=$_SESSION['Total'];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM registration WHERE email = '$promail'";
$result = mysqli_query($conn, $sql);
$row2 = $result->fetch_assoc();
$sql1 = "SELECT * FROM registration WHERE email = '$conmail'";
$result1 = mysqli_query($conn, $sql1);
$row1 = $result1->fetch_assoc();
$sql3 = "SELECT * FROM producer WHERE email = '$promail'";
$result3 = mysqli_query($conn, $sql3);
$row3 = $result3->fetch_assoc();

$aq = $row3['qty'];
$fq = $aq - $qty1;

$sql4 = "UPDATE producer SET qty = '$fq' WHERE email = '$promail'";
$result4 = mysqli_query($conn, $sql4);


$sql2 = "INSERT INTO orders (ordate,product, qty, promail, conmail) VALUES (CURRENT_TIMESTAMP,'$type1', '$qty1', '$promail','$conmail')";
$result2 = mysqli_query($conn,$sql2);

$sql9 = "SELECT * FROM trans1";
$result9 = mysqli_query($conn,$sql9);

if ($result9->num_rows > 0) {
    
  // output data of each row
  $i=0;
  while($row9 = $result9->fetch_assoc()) 
  {
    if($row9['exid'] AND $i<6)
    	$ei = $row9['exid'];
    	$sql11 = "SELECT orderno FROM orders WHERE ordate = CURRENT_TIMESTAMP";
    	$result11 = mysqli_query($conn, $sql11);
    	$row11 = $result11->fetch_assoc();
    	$on = $row11['orderno'];

    	$sql10 = "INSERT INTO trans (exid, orderno, status2) VALUES ('$ei', '$on', 'PENDING')";
    	$result10 = mysqli_query($conn, $sql10);
    	$i++;
    }
}

$sender = "TSTSMS";
$auth= "D!~2092RgMd02RR0B";
$mob = $row2['mobile'];
$msg = urlencode("testing to producer"); 

$url1 = 'https://global.datagenit.com/API/sms-api.php?auth='.$auth.'&msisdn='.$mob.'&senderid='.$sender.'&message='.$msg.'';  // API URL

$result5=SendSMS($url1);  // call function that return response with code
function SendSMS($hostUrl){
$ch1 = curl_init();
curl_setopt($ch1, CURLOPT_URL, $hostUrl);
curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch1, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch1, CURLOPT_POST, 0);
curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, 0); // change to 1 to verify cert
curl_setopt($ch1, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
//curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
$result5 = curl_exec($ch1);
return $result5;
} 

$sender1 = "TSTSMS";
$auth1 = "D!~2092RgMd02RR0B";
$mob2 = $row1['mobile'];
$msg2 = urlencode("testing for consumer"); 

$url2 = 'https://global.datagenit.com/API/sms-api.php?auth='.$auth1.'&msisdn='.$mob2.'&senderid='.$sender1.'&message='.$msg2.'';  // API URL

$result6=SendSMS1($url2);  // call function that return response with code
function SendSMS1($hostUrl){
$ch2 = curl_init();
curl_setopt($ch2, CURLOPT_URL, $hostUrl);
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch2, CURLOPT_POST, 0);
curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, 0); // change to 1 to verify cert
curl_setopt($ch2, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
//curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
$result6 = curl_exec($ch2);
return $result6;
}
echo "<br>";

echo "Your order is placed. Kindly pay the given ammount on the time of delivery..!";
header("refresh:2;url=dashboard.html");
?>