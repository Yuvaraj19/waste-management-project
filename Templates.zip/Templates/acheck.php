<?php

$admin_email=$_POST['admin_email'];
$a_pswd=$_POST['a_pswd'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";
$destype2 = "Complaint";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM admins WHERE admail = '$admin_email'";
$result = mysqli_query($conn, $sql);
$row = $result->fetch_assoc();

if($admin_email == $row['admail'] AND $a_pswd == $row['adpswd']) {

echo "Logged in successfully....Welcome Admin...!";
header("refresh:2;url=adashboard.php");
} else {
echo "Wrong creddentilas...!";
header("refresh:2;url=alogin.php");
}

?>
