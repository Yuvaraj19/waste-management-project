<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: black;
}

* {
  box-sizing: border-box;
}


/* Add padding to containers */
.container {
  padding-left: 300px;
  padding-right: 300px;
  padding-top: 80px;
  padding-bottom: 80px;
  background-color: #ffffff;
}

/* Full-width input fields */
input[type=text], input[type=password], input[number]{
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 30%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body style="background-image:url(images/cd.jpg)">
<form name = f5 , method = "POST" style="background-image:url(images/cd.jpg);">
  <div class="container" class="gtco-cover" role="banner" style="background-image:url(images/cd.jpg)">
  <div class="overlay" ></div>
    <h1><center style='color:white' strong>MY PROFILE</center></h1><br>
    <p></p>
    <?php
		session_start();
		

		$servername = "127.0.0.1";
		$username = "root";
		$password = "";	
		$dbname = "reuse";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    printf("connection failed!");
}
else
{	
	$gmail=$_SESSION['Email'];
	$query="SELECT * FROM registration WHERE email='$gmail'";
	
	$result=mysqli_query($conn,$query);
	$row = $result->fetch_assoc();
	
	echo "<center><p style='color:white; padding : 10px 30px; width : 500px;'>"."<strong>Company Name  :  </strong>".$row['cname']."</center></p><br>";
	echo "<center><p style='color:white; padding : 10px 30px; width : 500px;'>"."<strong>Email  :  </strong>".$gmail."</center></p><br>";
	echo "<center><p style='color:white; padding : 10px 30px; width : 500px;'>"."<strong>Mobile  :  </strong>".$row['mobile']."</center></p><br>";
	echo "<center><p style='color:white; padding : 10px 30px; width : 500px;'>"."<strong>Landline  :  </strong>".$row['lmobile']."</center></p><br>";
	echo "<center><p style='color:white; padding : 10px 30px; width : 500px;'>"."<strong>Location  :  </strong>".$row['location']."</center></p><br>";
	
}
	?>


  </div>
  
</form>

</body>
</html>
