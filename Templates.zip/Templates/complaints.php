
<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  padding-left: 20px;
}

td, th {
  border: 1px solid black;
  text-align: left;
  padding: 10px 20px;
}

tr {
  background-color: #ccc;
}
  .btn {
  margin-right: 4px;
  margin-bottom: 4px;
  font-family: "Raleway", Arial, sans-serif;
  font-size: 16px;
  font-weight: 400;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  -ms-border-radius: 4px;
  border-radius: 4px;
  -webkit-transition: 0.5s;
  -o-transition: 0.5s;
  transition: 0.5s;
  padding: 8px 30px;
}
.btn-primary {
  background: #F85A16;
  color: #fff;
  border: 2px solid #F85A16 !important;
}
.btn.btn-lg {
  padding: 18px 36px !important;
}
  .sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 8px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>

</head>


<body style="background-image: url(images/p3.jpg)">
  <font color="black">
    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>
<div id="sidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" align="right" onclick="closeNav()">&times;</a>
    <a href="adashboard.php">Dashborad</a>
    <a href="review.php">Reviews</a>
    <a href="aorders.php">Orders</a>
    <a href="complaints.php" class="active">Complaints(<?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "reuse";
          $j=0;
          $conn = new mysqli($servername, $username, $password, $dbname);

          $sql1 = "SELECT status FROM recom";
        $result1 = mysqli_query($conn,$sql1); 
         while($row1 = $result1->fetch_assoc()) {
         if($row1['status'] == "NOT SOLVED") {
          $j++;
         }
      }
      echo $j;

        ?>)</a>


</div>



<h1 align="center">Complaints</h1>




<header id="gtco-header" class="gtco-cover" role="banner">
    
          <div class="display-t">
            <div class="display-tc animate-box" data-animate-effect="fadeIn">
              <form name="f5" method="POST" action="check1.php">
              <div>
                <table style="padding: 10px; margin-left: 20px; margin-right: 20px; padding-left: 175px">
                  <tr>
                    <th style="padding: 10px 10px">S.No</th>
                    <th style="padding: 10px 20px">ID</th>
                    <th style="padding: 10px 20px">Company</th>
                    <th style="padding: 10px 40px">E-mail</th>
                    <th style="padding: 10px 20px">Mobile</th>
                     <th style="padding: 10px 50px">Date,Time</th>
                    <th style="padding: 10px 40px">Description</th>
                    <th style="padding: 10px 7px">Status</th>
                  </tr>
                

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";
$destype2 = "Complaint";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql4 = "SELECT * FROM recom WHERE destype='$destype2'";
$result4 = mysqli_query($conn,$sql4);

if ($result4->num_rows > 0) {
    
  // output data of each row
  $j=1;
  while($row4 = $result4->fetch_assoc()) 
  {
    $v2= $row4["email"];
    $sql5 = "SELECT * FROM registration WHERE email='$v2'";
    $result5 = mysqli_query($conn,$sql5);
    $sql6 = "SELECT * FROM recom WHERE email='$v2'";
    $result6 = mysqli_query($conn,$sql6);

    if ($result5->num_rows > 0 AND $result6->num_rows > 0) {
    // output data of each row
    while($row4 = $result5->fetch_assoc() AND $row6 = $result6->fetch_assoc()) 
    {
     
      echo "<tr>"."<th style='padding: 10px 30px' >".$j."</th>"
      ."<th style='padding: 10px 30px' >".$row6['compid']."</th>"
      ."<th style='padding: 10px 40px'>". $row4['cname'] ."</th>"
      ."<th style='padding: 10px 50px'>". $row4['email'] ."</th>"
      ."<th style='padding: 10px 30px'>". $row4['mobile'] ."</th>"
      ."<th style='padding: 10px 40px'>". $row6['date'] ."</th>"
      ."<th style='padding: 10px 30px'>". $row6['des'] ."</th>"
      ."<th style='padding: 10px 30px'>". $row6['status'] ."</th>"
      ."</tr>";
      
      $j++;
    }
}
else 
{
    echo "0 results";
}

    }
}
else 
{
    echo "0 results";
}


?>

          </table><br>
          <div class="wm-section wm-text-black" align="center">
                  <label1 for="email"><b style="padding-left: 30px;">Enter Company ID : </b></label1>
                <input type="number" placeholder="Enter complaint ID" name="compid" style = "width : 200px;border-radius : 5px; padding-left : 10px;margin-bottom : 30px; text" required><br>
          <div align="center">
          <button class="btn btn-primary btn-lg-1" align="center">Action</div>
        </form>
        </div>
        </div>
        </div>
</header>
	<script>
function openNav() {
  document.getElementById("sidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("sidenav").style.width = "0";
}
</script>
	
	
	
</font>
</body>

</html>