<?php

session_start();
	
$cname = $_POST["cname"];
$email = $_POST["email"];
$pswd = $_POST["pswd"];
$pswdrepeat = $_POST["pswdrepeat"];
$mobile = $_POST["mobile"];
$lmobile = $_POST["lmobile"];
$location = $_POST["location"];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";

$conn = new mysqli($servername, $username, $password, $dbname);

if($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
$sql2 = "SELECT * FROM registration";
$result = mysqli_query($conn,$sql2);
$row = $result->fetch_assoc();

if($row['email'] == $email) { 
echo "User already exists.";
} else {
if($pswd == $pswdrepeat) {
$sql = "INSERT INTO registration (cname,email,pswd,mobile,lmobile,location) VALUES ('$cname','$email','$pswd','$mobile','$lmobile','$location')";
if($conn->query($sql) === TRUE) {
echo "Registered successfully";
header("refresh:2;url=index.html");
} else {
	echo "Error: "  . $sql . "<br>" . $conn->error;
}
} else {
echo "Password don't match.";
}
}

?>
