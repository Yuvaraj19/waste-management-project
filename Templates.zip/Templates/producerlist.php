<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="widtd=device-widtd, initial-scale=1">
	

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href='https://fonts.googleapis.com/css?family=Raleway:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.tdeme.default.min.css">

	<!-- tdeme style  -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/style3.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body1>
		
	<div class="gtco-loader"></div>
	
	<div id="page">
	<nav class="gtco-nav" role="navigation" style="background-color: black; padding: 10px 0;">
		<div class="gtco-container">
			<div class="row">
				<div class="col-xs-2">
					<div id="gtco-logo"><a href="index.html">Re-Use</a></div>
				</div>
				<div class="col-xs-10 text-right menu-1">
					<ul>
						<li><a href="myprofile.php">My Profile</a></li>
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</div>
			</div>
			
		</div>
	</nav>

	<header id="gtco-header" class="gtco-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);">
		
					<div class="display-t">
						<div class="display-tc animate-box" data-animate-effect="fadeIn">
							<h1 align="center">Producers List</h1>
							<form name="f4" method="POST" action="http://localhost/trans.php">
							<div>
								<table style="padding: 10px; margin-left: 20px; margin-right: 20px">
									<tr>
										<th style="padding: 10px 10px">S.No</th>
										<th style="padding: 10px 10px">ID</th>
										<th style="padding: 10px 20px">Company</th>
										<th style="padding: 10px 40px">E-mail</th>
										<th style="padding: 10px 20px">Mobile</th>
										<th style="padding: 10px 20px">Landline</th>
										<th style="padding: 10px 25px">Location</th>
										<th style="padding: 10px 5px">Available quantity</th>
										<th style="padding: 10px 5px">Price(per kg/ltr)</th>
									</tr>
								

<?php
session_start();
$type=$_POST["type"];
$mail = $_SESSION['Email'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "reuse";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT email FROM producer WHERE type='$type'";
$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    
	// output data of each row
	$i=1;
	while($row = $result->fetch_assoc()) 
	{
		$v1= $row["email"];
		if($v1 != $mail) {
		$sql1 = "SELECT * FROM registration WHERE email='$v1'";
		$result1 = mysqli_query($conn,$sql1);
		$sql2 = "SELECT * FROM producer WHERE email='$v1'";
		$result2 = mysqli_query($conn,$sql2);

		if ($result1->num_rows > 0 AND $result2->num_rows > 0) {
		// output data of each row
		while($row = $result1->fetch_assoc() AND $row2 = $result2->fetch_assoc()) 
		{
			
			echo "<tr>"."<th style='padding: 10px 30px' >".$i."</th>"
			."<th style='padding: 10px 30px' >".$row['id']."</th>"
			."<th style='padding: 10px 40px'>". $row['cname'] ."</th>"
			."<th style='padding: 10px 50px'>". $row['email'] ."</th>"
			."<th style='padding: 10px 30px'>". $row['mobile'] ."</th>"
			."<th style='padding: 10px 30px'>". $row['lmobile'] ."</th>"
			."<th style='padding: 10px 30px'>". $row['location'] ."</th>"
			."<th style='padding: 10px 40px'>". $row2['qty'] ."</th>"
			."<th style='padding: 10px 40px'>". $row2['price'] ."/-"."</th>"
			."</tr>";
			
			/**echo "Company : ".$i."\t\t\t\t"."Email : " . $row['email'] . "<br>";
			echo "<br>"."Email : " . $row['email'] . "<br>";
			echo "Company Name : " . $row['cname'] . "<br>";
			echo "Mobile : " . $row['mobile'] . "<br>";
			echo "Landline : " . $row['lmobile'] . "<br>";
			echo "Location : " . $row['location'] . "<br><br>";*/
			
			$i++;
		}
		}
		else 
		{
			echo "0 results";
		}
		}
	}


    }
else 
{
    echo "0 results";
}


?>

					</table><br>
					<div class="wm-section wm-text-black" align="center">
							    <label1 for="email"><b style="padding-left: 30px;">Enter Company ID : </b></label1>
								<input type="number" placeholder="Enter ID" name="id" style = "width : 200px;border-radius : 5px; padding-left : 10px;margin-bottom : 30px; text" required><br>
								<label1 for="qtyreq" ><b>Required Quantity : </b></label1>
								<input type="number" name="qty" style = "width : 75px;border-radius : 5px; padding-left : 10px;margin-bottom : 30px" required>

					<br><br>
					</div>
					<div align="center">
					<button class="btn btn-primary brn-lg-1" align="center">Submit</div>
				</form>
				</div>
				</div>
				</div>
</header>
	
	

	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>

	</body1>
</html>

