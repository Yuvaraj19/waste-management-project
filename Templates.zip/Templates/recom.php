<?php
	session_start();
	$email=$_SESSION['Email'];
	$destype=$_POST['destype'];
	$des=$_POST['des'];

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "reuse";


	if($email && $destype && $des) {
		$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Can't connect");

		if($destype == 'Review') {				
		$sql = "INSERT INTO recom (email,destype,des,date,status) VALUES ('$email','$destype','$des',CURRENT_TIMESTAMP,'---')";
		$result=mysqli_query($conn,$sql);
		echo "Submitted successfully.Thank you for your review. We will keep improving for your comfort.";
	} elseif ($destype == 'Complaint') {
		$sql2 = "INSERT INTO recom (email,destype,des,date,status) VALUES ('$email','$destype','$des',CURRENT_TIMESTAMP,'NOT SOLVED')";
		$result2=mysqli_query($conn,$sql2);
		echo "Submitted successfully.Your complaint is forwarded to our experts.";
	}
	} else {
		echo "Submission failed due to insufficient data. Please try again.";
	}
	header("refresh:2;url=dashboard.html");
?>